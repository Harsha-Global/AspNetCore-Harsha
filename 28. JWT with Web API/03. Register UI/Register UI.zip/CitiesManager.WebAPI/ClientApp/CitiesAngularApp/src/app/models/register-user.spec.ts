import { RegisterUser } from './register-user';

describe('RegisterUser', () => {
  it('should create an instance', () => {
    expect(new RegisterUser()).toBeTruthy();
  });
});
