export class LoginUser {
  email: string | null = null;
  password: string | null = null;
}
