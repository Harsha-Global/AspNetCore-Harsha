export class RegisterUser {
  personName: string | null = null;
  email: string | null = null;
  phoneNumber: string | null = null;
  password: string | null = null;
  confirmPassword: string | null = null;
}
