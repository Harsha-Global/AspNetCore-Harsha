﻿using Microsoft.AspNetCore.Identity;

namespace CitiesManager.Core.Identity
{
 public class ApplicationRole : IdentityRole<Guid>
 {
 }
}
